//logout.js

export const logout = () => {
    // Click on the "Logout" button
    cy.get('#logoutBtn').click();
  
    // Verify that the page is now on the login page 
    cy.url().should('include', '/login');
  
    // Verify that a specific text related to the Contact List App is present on the page
    cy.contains('Contact List App').should('exist');
  };
  