import { createContact } from './contact.js'; 
import { login } from './login.js';
import { logout } from './logout.js';
import { contactData } from 'data/contactData.js';

describe('Edit Contact Test', () => {
  beforeEach(() => {
    login();
     createContact();
  });

  it('Edits the created contact', () => {
    // Click on the first name in the table to navigate to contact details
    cy.contains(contactData.firstName).click();

    // Verify that the page is now on the contact details page
    cy.url().should('include', '/contactDetails');

    // Click on the "Edit Contact" button
    cy.get('#editContactBtn').click();

    // Verify that the page is now on the edit contact page
    cy.url().should('include', '/editContact');

    // Modify the contact's name to a new name
    const newFirstName = 'Shaydar';
    cy.get('#firstName').clear().type(newFirstName);


    cy.get('#submitContactBtn').click();

    // Verify that the contact has been edited successfully
    cy.contains(`Click on any contact to view the ${newFirstName} ${contactData.lastName}`).should('exist');
  });
});
after(() => {
    logout();
  });