describe('UI Test for Sign Up Form', function () {
  const userData = {
    firstName: 'ValidFirstName',
    lastName: 'ValidLastName',
    email: 'valid.email@example.com',
    password: 'ValidPassword123'
  };

  it('should fill in the sign-up form and submit successfully', function () {
    const baseUrl = 'https://thinking-tester-contact-list.herokuapp.com';
    const signUpUrl = `${baseUrl}/adduser`;

    cy.visit(signUpUrl);

    // Fill in the sign-up form
    cy.get('#firstName').type(userData.firstName);
    cy.get('#lastName').type(userData.lastName);
    cy.get('#email').type(userData.email);
    cy.get('#password').type(userData.password);

    // Click the Submit button
    cy.get('#submitBtn').click();

    // Assertions for successful sign-up
    cy.url().should('eq', `${baseUrl}/contactList`);
    cy.contains('Contact List').should('exist');
    
  });
});

