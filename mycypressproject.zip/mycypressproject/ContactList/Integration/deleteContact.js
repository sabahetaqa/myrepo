
import { createContact } from './contact.js'; 
import { login } from './login.js';
import { logout } from './logout.js';
import { contactData } from 'data/contactData.js';

describe('Delete Contact Test', () => {
  beforeEach(() => {
    login();
    createContact();
  });

  it('Deletes the created contact', () => {
    cy.contains(contactData.firstName).click();
    cy.url().should('include', '/contactDetails');

    // Click on the "Delete Contact" button
    cy.get('#deleteContactBtn').click();
    cy.get('.confirm-button-ok').click();

    // Verify that the contact has been deleted successfully
    cy.contains(`Click on any contact to view the ${contactData.firstName} ${contactData.lastName}`).should('not.exist');
  });
});
after(() => {
    logout();
  });