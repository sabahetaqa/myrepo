// cypress/integration/returnToContactList.js

import { createContact } from './contact.js';  
import { login } from './login.js';
import { logout } from './logout.js';
import { contactData } from 'data/contactData.js';

describe('Return to Contact List Test', () => {
  beforeEach(() => {
    login();
    createContact();
  });

  it('Returns to the contact list from contact details page', () => {
    cy.contains(contactData.firstName).click();
    cy.url().should('include', '/contactDetails');

    // Click on the "Return to Contact List" button
    cy.get('#returnToContactListBtn').click();

    // Verify that the page is now back on the contact list page
    cy.url().should('include', '/contactList');

    // Verify that the contact is still present in the contact list
    cy.contains(`Click on any contact to view the ${contactData.firstName} ${contactData.lastName}`).should('exist');
  });
});
after(() => {
    logout();
  });