// cypress/integration/contact.js

import { login } from './login.js';
import { logout } from './logout.js';
import { contactData } from 'data/contactData.js';

// Function to create a new contact
export const createContact = () => {
  // Call the login function to ensure the user is logged in before each test
  login();

  cy.get('#addNewContactBtn').click();

  cy.url().should('include', '/addContact');

  // Fill in the contact creation form with the provided data
  cy.get('#firstName').type(contactData.firstName);
  cy.get('#lastName').type(contactData.lastName);
  cy.get('#birthdate').type(contactData.birthdate);
  cy.get('#email').type(contactData.email);
  cy.get('#phone').type(contactData.phone);
  cy.get('#street1').type(contactData.street1);
  cy.get('#street2').type(contactData.street2);
  cy.get('#city').type(contactData.city);
  cy.get('#stateProvince').type(contactData.stateProvince);
  cy.get('#postalCode').type(contactData.postalCode);
  cy.get('#country').type(contactData.country);

  // Click the button to submit the contact creation form
  cy.get('#submitContactBtn').click();

  cy.contains(`Click on any contact to view the ${contactData.firstName} ${contactData.lastName}`).should('exist');
};
after(() => {
    logout();
  });