// cypress/integration/login.js

export const login = () => {
  // Visit the login page
  cy.visit('https://thinking-tester-contact-list.herokuapp.com/login');

  // Fill in the login form
  cy.get('#username').type('test@fakesabi1.com');
  cy.get('#password').type('myPassword');

  // Click the login button
  cy.get('button[type="submit"]').click();

  // Verify successful login
  cy.url().should('include', '/contacts');
  cy.contains('Welcome to Your Contacts!').should('exist');
};

  